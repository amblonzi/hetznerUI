import { create } from 'zustand';

interface ServerData {
  id: string;
  name: string;
  ip: string;
  status: string;
}

interface Metrics {
  [serverId: string]: {
    cpu: number;
    memUsed: number;
    memTotal: number;
    netRx: number;
    netTx: number;
    history: any[];
  }
}

interface AppState {
  servers: ServerData[];
  cloudServers: any[];
  metrics: Metrics;
  setServers: (servers: ServerData[]) => void;
  setCloudServers: (servers: any[]) => void;
  updateMetrics: (serverId: string, data: any) => void;
}

export const useStore = create<AppState>((set) => ({
  servers: [],
  cloudServers: [],
  metrics: {},
  setServers: (servers) => set({ servers }),
  setCloudServers: (cloudServers) => set({ cloudServers }),
  updateMetrics: (serverId, data) => set((state) => {
    const currentMetrics = state.metrics[serverId] || { history: [] };
    const newHistory = [...currentMetrics.history, data].slice(-60); // keep last 60 points
    return {
      metrics: {
        ...state.metrics,
        [serverId]: {
          cpu: data.cpu.usage_percent,
          memUsed: data.memory.used,
          memTotal: data.memory.total,
          netRx: data.network.rx_bps,
          netTx: data.network.tx_bps,
          history: newHistory
        }
      }
    };
  })
}));
