import { useEffect } from 'react';
import Dashboard from './components/Dashboard';
import { useStore } from './store';
import { io } from 'socket.io-client';
import axios from 'axios';
import { Activity, HardDrive, Cloud, Terminal } from 'lucide-react';

const socket = io(import.meta.env.VITE_BACKEND_URL || 'http://localhost:3000');

function App() {
  const { setCloudServers, updateMetrics } = useStore();

  useEffect(() => {
    // Listen for real-time metrics
    socket.on('metrics_update', (data) => {
      updateMetrics(data.server_id, data);
    });

    // Fetch initial data
    axios.get(`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:3000'}/api/cloud/servers`)
      .then(res => setCloudServers(res.data.servers || []))
      .catch(console.error);

    return () => {
      socket.off('metrics_update');
    };
  }, [setCloudServers, updateMetrics]);

  return (
    <div className="flex h-screen bg-slate-900 text-white">
      {/* Sidebar */}
      <div className="w-64 bg-slate-800 p-4 border-r border-slate-700">
        <h1 className="text-2xl font-bold text-blue-400 mb-8">Hetzner Dash</h1>
        <nav className="space-y-2">
          <a href="#overview" className="flex items-center gap-3 p-3 bg-blue-600 rounded-lg">
            <Activity size={20} /> Overview
          </a>
          <a href="#hardware" className="flex items-center gap-3 p-3 hover:bg-slate-700 rounded-lg">
            <HardDrive size={20} /> Hardware
          </a>
          <a href="#cloud" className="flex items-center gap-3 p-3 hover:bg-slate-700 rounded-lg">
            <Cloud size={20} /> Cloud Resources
          </a>
          <a href="#processes" className="flex items-center gap-3 p-3 hover:bg-slate-700 rounded-lg">
            <Terminal size={20} /> Inspection
          </a>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        <Dashboard />
      </div>
    </div>
  );
}

export default App;
