import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import axios from 'axios';
import { Client } from 'ssh2';
import Database from 'better-sqlite3';

dotenv.config({ path: '../.env' });

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(cors());
app.use(express.json());

// SQLite Database Setup
const db = new Database('./data.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    cpu_percent REAL,
    mem_used INTEGER,
    mem_total INTEGER,
    rx_bps INTEGER,
    tx_bps INTEGER
  );
  CREATE TABLE IF NOT EXISTS servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    ip TEXT,
    ssh_user TEXT,
    ssh_password TEXT,
    ssh_key_path TEXT
  );
`);

// Hetzner Cloud API Helper
const hetznerApi = axios.create({
  baseURL: 'https://api.hetzner.cloud/v1',
  headers: {
    Authorization: `Bearer ${process.env.HETZNER_API_TOKEN}`,
  },
});

// REST Routes
app.get('/api/cloud/servers', async (req, res) => {
  try {
    const response = await hetznerApi.get('/servers');
    res.json(response.data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Agent Metrics Ingestion
app.post('/api/metrics/ingest', (req, res) => {
  const data = req.body;
  const token = req.headers.authorization?.split(' ')[1];
  
  // Basic validation (in prod, verify token against DB)
  if (!data || !data.server_id) return res.status(400).send('Invalid data');

  const { server_id, cpu, memory, network } = data;
  
  // Save to SQLite
  const stmt = db.prepare('INSERT INTO metrics (server_id, cpu_percent, mem_used, mem_total, rx_bps, tx_bps) VALUES (?, ?, ?, ?, ?, ?)');
  stmt.run(server_id, cpu.usage_percent, memory.used, memory.total, network.rx_bps, network.tx_bps);

  // Broadcast to WebSockets
  io.emit('metrics_update', data);
  
  res.status(200).send('OK');
});

// SSH Helper for Process / Logs
app.post('/api/server/:ip/exec', (req, res) => {
  const { ip } = req.params;
  const { command } = req.body;
  // TODO: Fetch credentials from DB securely. For now, using mock.
  
  const conn = new Client();
  conn.on('ready', () => {
    conn.exec(command, (err, stream) => {
      if (err) return res.status(500).send(err.message);
      let output = '';
      stream.on('close', () => {
        conn.end();
        res.json({ output });
      }).on('data', (data: any) => {
        output += data.toString();
      }).stderr.on('data', (data: any) => {
        output += data.toString();
      });
    });
  }).on('error', (err) => {
    res.status(500).send(err.message);
  }).connect({
    host: ip,
    port: 22,
    username: req.body.ssh_user || 'root',
    password: req.body.ssh_password || 'your_server_password_here',
    // Or you can still use privateKey: require('fs').readFileSync('/path/to/key')
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Backend server running on port ${PORT}`);
});
